import java.util.Scanner;

class Stack<V> {
	V[] data;
	int top;
	Stack() {
		data = (V[])new Object[1000];
		top = -1;
	}
	void push(V vps) {
		top++;
		data[top] = vps;
	}
	public void pop() {
		data[top] = null;
		top--;
	}
	public V top() {
		return data[top];
	}

}

public class Main {
	public static void main(String[] args) {
		Stack<String> temp = new Stack();
		Stack<String> result = new Stack();
		Scanner scan = new Scanner(System.in);
		int num = scan.nextInt();
		String vv;
		String emp = scan.nextLine();
		for(int k = 0; k < num; k++) {
			vv = scan.nextLine();
			int j = vv.length();
			int a = 0;
			int b = 0;
			char x = '(';
			char y = ')';
			char z;
			for(int i = 0; i < j; i++) {
				z = vv.charAt(i);
				if(z == x) {
					a++;
				}
				else {
					b++;
				}
			}
			if(vv.charAt(0) == ')') {
				temp.push("No");
			}
			else if(a == b) {
				temp.push("YES");
			}
			else {
				temp.push("NO");
			}
		}
		for(int i = 0; i < num; i++) {
			String re = temp.top();
			result.push(re);
			temp.pop();
		}
		for(int i = 0; i < num; i++) {
			System.out.println(result.top());
			result.pop();
		}
	}
}